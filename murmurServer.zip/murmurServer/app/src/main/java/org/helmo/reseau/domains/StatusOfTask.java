package org.helmo.reseau.domains;

public enum StatusOfTask {
    WAITING, IN_PROGRESS, DONE, ERROR
}
